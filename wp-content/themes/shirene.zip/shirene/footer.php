
<footer>
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <p class="botm-ftr-text">© 2024 All rights reserved Shirene Anand</p>
            </div>
            <div class="col-lg-6">
                <ul>
                    <li><a href="mailto:shirene.anand@gmail.com">Email</a></li>
                    <li><a href="https://www.instagram.com/shirenexanand/">Instagram</a></li>
                    <li><a href="https://www.linkedin.com/in/shireneanand/">Linkedin</a></li>
                </ul>
            </div>
            <!-- <div class="col-lg-6">
            <div class="social-icons">
            <a class="social-icon twitter" href="#">
                <i class="fab fa-twitter"></i>
            </a>
            <a class="social-icon dribbble" href="#">
                <i class="fab fa-dribbble"></i>
            </a>
            <a class="social-icon facebook" href="#">
                <i class="fab fa-facebook-f"></i>
            </a>
            <a class="social-icon instagram" href="#">
                <i class="fab fa-instagram"></i>
            </a> -->
            <!-- <a class="social-icon github" href="#">
                <i class="fab fa-github"></i>
            </a> -->
            </div>
            </div>
        </div>
    </div>
</footer>
<?php wp_footer()?>

</body>
</html>